using System;
using System.Collections.Generic;
using System.Configuration;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using PX.Objects.CS;
using PX.Web.UI;
using PX.Data;

public partial class Page_US100000 : PXPage
{
    protected void Page_Init(object sender, EventArgs e)
    {
    }
}
